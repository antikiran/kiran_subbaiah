
/* Local Function Prototypes for USE_ME.EXE.
 * 
 * Source File: parentmain.cpp
 *   
 * Naming convention is modulename_description()
 *
 */

/* Function Prototypes (Routines) */

long CALLBACK wndproc(HWND,UINT,WPARAM,LPARAM ); //Custom message procedures for the main_window. 
												 //This is the main routine that calls other routines.

BOOL is_key_pressed(WPARAM keycode, LPARAM keycode_ext ); //Returns TRUE with parameters containing value of key 
														  //that was pressed when a system or windows keys is pressed.

void key_pressed(WPARAM keycode, LPARAM keycode_ext );	// If is "is_key_pressed" returns TRUE this function provides 
														// the approriate text for, and creates a Message Box.

void save_desktop(void);   // Saves an image of the desktop.
void release_desktop(void);// deletes the saved image of the desktop.
void restore_desktop(void);// repaints the desktop with the image of it
						   // taken before being defaced by an effect.





/* TOOLS */
void tool_launch(void ); //Common routine fo launching tools in a given sequence.
						

void tool_cursor_trace(void ); // Leaves images of cursor on the desktop along the path
							   // travelled by cursor. Creates 7 other pseudo-cursors
							   // at positions on the screen that are different from but
							   // related to the position of the real cursor. 

void tool_scratch_vert(void );	// A narrow vertical section of the screen at the x-position of 
								// the cursor is copied, flipped vertically and pasted an the same position.
 
void tool_flip_vert(void );     // a rectangular section of the screen copied from the x and y position
								// inverse to that of the cursor, and pasted at the position of cursor
 								// upside-dowm, flipped horizontally.

void tool_scratch_horiz(void ); // A narrow horizontal section of the screen at the y-position  of the cusor
								// is displaced horizontally by a few pixels. 

void tool_smudge(void );		// A rectangular section of the screen copied from one side of the cursor and
								// pasted on the other side turned upside down and flipped horizontally. 


void tool_drag_desktop_invert(void); // A negative (color) image of the screen seen at the position on the screen
									 // inversly opposite to that of the cursor, when the cursor is moved.


void tool_drag_desktop(void);	// screen displaced to a position inversly opposite to that of cursor position. 






/* TYPE WINDOW  */
void type_launch(void );	// Launches a type window
void type_kill(void );		// Destroys a type window
BOOL type_msg_parse(WPARAM wp, LPARAM lp ); // Checks to see if a message has been sent to the
											// main window from the type window.
void random_char(char * key ); // Generates a random character when a character key is pressed
void shake_cursor(void);	   // Makes the cursor shake when it is moved.




/* TRANSITIONS */
void tool_to_type(void ); // Common routine for ending a tool and starting a type window.
void type_to_tool(void ); // Common routine for ending a type window and starting a tool.



/* DISPLAY MALFNCTION EMULATIONS*/

void hw_malfunc_emu(void );	// Common routine for launching a malfunction effect.

void hw_malfunc_emu_quiver(void );	// Screen sliced into many (160) vertical sections that
									// oscillate vertically at different dispacement rates.

void hw_malfunc_emu_jitterpaint(void); // Screen shakes and changes color briefly. 
 
void hw_malfunc_emu_quiver_invert(void ); // Same as "hw_malfunc_emu_quiver", except that for
										  // alternation between positive and negetive image.

void hw_malfunc_emu_vhold(void );		// Screen rolls vertically. speed and direction relative to
										// the y-position of cursor.


void hw_malfunc_emu_flash_invert(void );	// Screen color alternates between negetive and positive.
											// Also shifts slightly with random values in x and y axes
											// creating a blurred effect.

void hw_malfunc_emu_hhold(void );		// Screen rolls horizontally. Speed and direction relative to 
										// horizontal position of cursor.

void hw_malfunc_emu_slicenshuffle(void ); // Screen sliced into assorted rectangular sections and shuffled
										  // around a few times.

void hw_malfunc_emu_jitter(void ); // Screen vibarates diagonally.

void hw_malfunc_emu_vhold_noise(void ); // similar to "hw_malfunc_emu_vhold" except for image-noise seen
										// above and below the rolling image.

/* PM5 */
void enough_of_acting_the_goat(void );	// program closing screen effect and message box.
BOOL SelfDelete(void); //Delete myself from disk.