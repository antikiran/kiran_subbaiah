

/*******************************************************************************************************************/
/*******************************************************************************************************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/ 
/**************************   U   U   SSSs  EEEEe       M   M  EEEEe    EEEEe X   X EEEEe   ************************/
/**************************   U   U  S      E           MM MM  E        E      X X  E       ************************/
/**************************   U   U   SSS   EEE         M M M  EEE      EEE     X   EEE     ************************/
/**************************   U   U      S  E           M   M  E     ++ E      X X  E       ************************/
/**************************    UUU   SSSS   EEEEE ===== M   M  EEEEE ++ EEEEE X   X EEEEE   ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/**************************                                                                 ************************/
/*******************************************************************************************************************/
/**************************                                                                 ************************/
/**************************   DESKTOP DEFACING AND DISPLAY MALFUNCTION EMULATION SOFTWARE   ************************/
/**************************                                                                 ************************/
/*******************************************************************************************************************/
/**************************************                                        *************************************/
/************************************** Created at: MAHITI INFOTECH, Bangalore *************************************/
/**************************************            www.mahiti.org              *************************************/
/*******************************************************************************************************************/
/***************************                                                               *************************/
/*************************** Scripted by: CHERRY GEORGE MATHEW, AMITA JAIN, KIRAN SUBBAIAH *************************/
/*******************************************************************************************************************/
/***************************                                                               *************************/
/***************************  Funded by: THE RIJKSAKDEMIE VAN BEELDENDE KUNSEN, Amsterdam. *************************/
/***************************                    www.rijksakademie.nl                       *************************/
/*******************************************************************************************************************/
/***************************                                                               *************************/
/***************************                   Concept: KIRAN SUBBAIAH                     *************************/
/*******************************************************************************************************************/
/*******************************************************************************************************************/

////////////////////////////////
/* DEFINITIONS AND INCLUSIONS */
////////////////////////////////

#include <windows.h>  // Header file for declarations of storage-classes, type specifiers, 
					  // inclusion of other header files, etc.
					  // Visual Studios file.

#include <time.h>	  // Declares "time" identifer for generating random seed.
					  // Visual Studios file.

#define OEMRESOURCE	    // Original Equipment Manufacture's resources: cursors, icons, etc.

#include "storyboard.h" // Custom Header file for this project.
						// Should be in this project directory for compiling.

#define MAIN_WIN_CLASS "selfpainted"		  // Parent window.
#define TRANSPARENT_TYPE_CLASS "transparent"  // Type windows. 

/* Custom debug box to check for errors after compile and build. */
#define DEBUG_BOX       MessageBox( h_main_window,          \
                                    "DEBUG",          \
                                    "MESSAGE" ,     \
                                    MB_ICONEXCLAMATION | MB_OK ); \

#define MOUSETHRESHOLD 1	// For detecting mouse moves. 1 pixel.

/* All timeouts are in multiples of half a second. */
#define HW_TIMEOUT 2		// For setting duration of Hardware Malfunction Emulations.  
	

/////////////////////////
/* GLOBAL DECLARATIONS */
/////////////////////////

int width_main_window, height_main_window; // For registering user's screen dimensions.

/* Flags are updated by the transition functions independantly ie; 
 * type_to_tool() resets type_flag and sets tool_flag, HW_TIMEOUT
 * type_launch() only sets the type_flag, doesn't touch the tool_flag.
 * June 29th, cherry: we begin by setting the tool_flag to start off
 * with the tool. */
int tool_count = 0,				  // For creating a sequence for launching tools.
	tool_flag = 1, type_flag = 0, // For toggling between type and tool. Starts with a tool.
	tool_cycle = 1,				  // To count the number of tool loop cycles
	hw_malfunc_count = 0,		  // For creating a sequence of Hardware malfunction emulations.
	hw_value_range = 2,			  // For setting and amplifying displacement values of HW Malfunct emu.
	begin_end_flag = 0;			  /* General-purpose recyclable flag for miscellaneous use, 
								   * to be reset to "0" before being dispensed with.*/ 	

HINSTANCE hinst_main;	   // Handle to instance.
MSG	msg;			  	   // Stores messages in queue.
HWND h_main_window;		   // Handle to main window
HWND h_type_window = NULL; /* Handle to text box. Global Scope is used as a flag.
                            * If h_type_window == NULL, module "type" is inactive
                            * transitions like tool_to_type, take care of resetting
                            * its value.
                            */

WNDCLASS wc, tc;		 // wc = main_window class, tc = type_window class.
POINT p0,p1;			 // Two points for registering position & detecting movement of cursor.
ICONINFO s_cursor_info;  // To determine cursor properties.
HBITMAP h_desktop_bitmap;//	Handle to saved image of users desktop. where(directory name) is this saved?
HCURSOR h_default_cursor, type_cursor;// Handle to cursor.
HDC dc_main_window, dc_saved;		  /* Device contexts. dc_saved is shared, used and reset by some tools 
									   * and all  HW malfunction emulations. */



/*Windows Application Programing Interface parameters.*/
int WINAPI WinMain(HINSTANCE h,HINSTANCE hp,LPSTR cmd, int show){
/*int WINAPI WinMain(
  HINSTANCE h,  // Handle to current instance
  HINSTANCE hp, // Handle to previous instance. 
				// Needs mutex to dis-allow two instances of the program from running simultaneously.
  LPSTR cmd,    // Pointer to command line
  int Show      // Show state of window
);*/


	/////////////////////
	/* INITIALIZATION. */
	/////////////////////

  /* Save instance handle in Global variable hinst_main. */
  hinst_main = h;

  /* Generate random seed. */
  srand( (unsigned)time( NULL ) );		// Pseudo random number generated from current time.

  
  /* Cursor Initialisations. */
  h_default_cursor = LoadCursor(NULL, IDC_ARROW); // Regular cursor for main_window
  GetIconInfo( h_default_cursor, &s_cursor_info); // To determine cursor position
  type_cursor = LoadCursor(NULL, IDC_HELP);		  // Cursor for type window; arrrow with question-mark.
  

  /* Only one instance of this program is allowed. */    
  if(hp) return FALSE;		// Does not work! It is still posssible to run two instances of this program at the same time.
							// To disable this, mutex has to be used at hp declaration in WINAPI WinMain(...).
							// We didnot bother to do it because it's almost impossible for the user to open a second
							// instance of this program while a first is running, and even if he manages to
							// nothing goes wrong.
  
  /* Customize "EDIT" control class. 
   * Re-register it under the name "transparent" a.k.a
   * TRANSPARENT_TYPE_CLASS. 
   * KIRAN: We could not get to make the type window background transparent.
   */
  GetClassInfo(NULL, "EDIT", &tc);			// -,"EDIT" ?, type class.
  tc.hbrBackground = NULL;					// Handle to background brush(left unpainted)
  tc.lpszClassName = TRANSPARENT_TYPE_CLASS;// Class name
  tc.hCursor = type_cursor;					// Handle to cursor with arrow and questionmark
  RegisterClass(&tc);						// For subsequent calls to CreateWindowEx

  /* Initialize Main Window Class */
  wc.lpfnWndProc = wndproc;		 // Creating windows procedure template?
  wc.hCursor = h_default_cursor; // Regular cursor

  /* To check for errors after compile and build. */ 
  if(h_default_cursor == NULL) DEBUG_BOX;  // If the IDC_ARROW is not found in resources
                                           // debug box is displayed
       
  wc.hbrBackground = NULL;		     // Handle to background brush(left unpainted)
  wc.lpszClassName = MAIN_WIN_CLASS; // Class name
  
  RegisterClass(&wc); // For subsequent calls to CreateWindowEx
  
  /*Creation of the Main Window */
  h_main_window = CreateWindowEx(WS_EX_TOPMOST, // Makes this the topmos window
                      MAIN_WIN_CLASS, // Pointer to registered class name
                      (LPCTSTR) NULL, // Pointer to window name
                      WS_POPUP,		  // Window style
                      CW_USEDEFAULT,  // Horiz position of window
                      CW_USEDEFAULT,  // Vertic position of window
                      CW_USEDEFAULT,  // Window width
                      CW_USEDEFAULT,  // Window height
                      (HWND) NULL,	  // Handle to parent
                      (HMENU) NULL,	  // Handle to menu or child window identifier
                      h,			  // Handle to application instance 
                      (LPVOID) NULL); // Pointer to windows creation data
  
  ShowWindow(h_main_window, SW_MAXIMIZE); // Window covers entire screen
  
  /* Get the device context of the main window for 
   * drawing within the main window. */
  dc_main_window = GetDC(NULL); 

  /* Get the width and height of a maximized screen window. */
  height_main_window = GetSystemMetrics(SM_CYSCREEN); // Retreives values of users screen-height...
  width_main_window = GetSystemMetrics(SM_CXSCREEN ); // and width and applies it to the main window...
													  // making it fullscreen.


  /* This LABEL loop checks for messages and  responds to them appropriately.
   * We've avoided the typical while(GetMessage) construct,
   * to prevent the program from blocking. ) */
  LABEL_GET_MESSAGE:
   
  if( PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) ){ // check for messages 
              
      /* Intercept messages (including user inputs)for the default message 
       * handler of the type_window edit control.*/
     if( (msg.hwnd == h_type_window) && (msg.hwnd != NULL) ) // If type window receives messages...
      {
        
        switch(msg.message) // Message categories:
        {

        /* If WM_CHAR message gets to "type" window, randomize the 
         * keycode in msg.wParam. */
          case WM_CHAR:					  	  // If character key is pressed... 
          random_char( (char *) &msg.wParam); // call routine "random_character"(with the value of the key pressed)
		  break;
		  
        /* All system keystrokes to the "type" window, are redirected to the main window. */
        case WM_KEYDOWN:							   // If a Windows key is pressed or... 
        case WM_SYSKEYDOWN:							   // a System key is pressed...
          if( is_key_pressed(msg.wParam, msg.lParam) ) // and if routine "is_key_pressed" returns TRUE...
            msg.hwnd = h_main_window;				   // let the main window handle the message 
          break;

        }
      }

     /* Call Window Procedures. */
      DispatchMessage(&msg);	// Sends the message
      TranslateMessage(&msg);	// Interprets the message
     }    

  if(msg.message == WM_QUIT) return 0; // Program quits when asked to, Post-quit message = "0".
  goto LABEL_GET_MESSAGE;			   // Loops this label.

}



 ////////////////////////
 /* WINDOWS PROCEDURES */
 ////////////////////////

/* This is the main message processing function for the main window from which other rotines and sub-routines are called*/
long CALLBACK wndproc(HWND hW, UINT m, WPARAM wp, LPARAM lp){ // Windows procedures
	switch(m){ //"m" contains the message received to select the appropriate case.
  
  /* If the mouse is moved, we call a "tool". */  
  case WM_MOUSEMOVE:	 // If the mouse is moved...
      GetCursorPos(&p1); //	register the current cursor position as "p1".
						 // (p0 registered below  at "case WM_CREATE")
  
	  /* if cursor postion changes after the main_window is created*/
    if ((p1.x - p0.x) >= MOUSETHRESHOLD || (p1.y - p0.y) >= MOUSETHRESHOLD
       || (p0.x - p1.x) >= MOUSETHRESHOLD || (p0.y - p1.y) >= MOUSETHRESHOLD){
	 
  /*update 'original' co-ords*/
    p0.x = p1.x;
    p0.y = p1.y;
    
  /* Mouse has been moved. Do Something. */
   if( (!type_flag) ) tool_launch(); // If type is not active, goto tool_launch routine
   else shake_cursor();				 // If type_flag = 1 go to shake_cursor routine
		
	}
  break;
   
  /* If we lose focus, we reclaim it forcibly. */  
  case WM_KILLFOCUS:		// When other windows try to claim focus... 
  case WM_ACTIVATE:			// or another program is activated...
  SetForegroundWindow(hW);  // let this program remain in the foreground. 
  break;

   case WM_COMMAND:	// Sent when user selects a command item from a menu, 
					// when a control sends a notification message to its parent window, 
					// or when an accelerator keystroke is translated. 

     if (type_msg_parse(wp, lp) ) break; // Checks if the message is from the type window...
										 // and if so whether it is to be handled by main_window.
										 // If this function returns true, main_window handles
										 // the message.
     
	 /* CHERRY: OK, lets give other functions that use WM_COMMAND, a chance. */
     /* Other WM_COMMAND processing functions go here */
     break;
     
    /* 26th June, keypress triggers type box. */
    /* If a key is pressed, we check for "keypress". */
  
   case WM_KEYDOWN:					// When windows keys are pressed...
   /* Takes care of alt- combinations, s/m menu etc*/

   case WM_SYSKEYDOWN:				// or System keys (F1...F12) are pressed...
    if ( is_key_pressed(wp, lp) )	// and if is_key_pressed routine returns true 
									// with (wp,lp) message parameters...
       {
        key_pressed(wp, lp);		// then call key_pressed routine with the (wp,lp) parameters
        type_to_tool();				// and type_to_tool transition routine.
        break;
       }
      
   case WM_LBUTTONDOWN: /* on mouse left click */

	   if( (!tool_flag) && (!type_flag) ) // If tool and type are both inactive...
		   type_launch();				  // then call type_launch routine.
		    
     /* June 27, Cherry: Introduced toggling between type and tool
      * on mouse clicks.*/
     if( type_flag ) type_to_tool(); // If type is active call transition routine type_to_tool().
     else tool_to_type();			 // If type is not active then call transition routine tool_to_type(). 
     break;	 
     
   case WM_RBUTTONDOWN:			 // On mouse right click...
    	   hw_malfunc_emu();	 // call hw_malfunc_emu() routine. 
     break;
   
   case WM_MBUTTONDOWN:			 // On mouse middle click...   
   case WM_DESTROY:				 // or message to destroy window...where would this come from?    
   case WM_CLOSE:				 // or message to close program... where would this come from? 
    enough_of_acting_the_goat(); // call this (end program) routine.
    break;


   case WM_CREATE:		// When the main_window is created (this application is launched)
     GetCursorPos(&p0);	// register current mouse position as p0.
						// to detect mouse move with p1 in case WM_MOUSEMOVE.
     break;

   default:									// For any other message not specified above...
     return DefWindowProc(hW, m, wp, lp);	// call default message procedures 
									    	// to ensures that all messages are processed.
  }
   
  return 0;

}


  //////////////////
  /* SUB-ROUTINES */
  //////////////////


/*This function is called from LABEL_GET_MESSAGE when h_type_window is active
 *and "long CALLBACK WndProc(...) when h_main_window is active.
 *Both on event of a Windowskeys or Systemkeys are pressed*/

BOOL is_key_pressed( WPARAM keycode, LPARAM keycode_ext){	//keycode = which of the following keys are pressed?	  

  switch (keycode) 
  {    
    case VK_MENU:
    case VK_CONTROL:
    case VK_LWIN:
    case VK_RWIN:
    case VK_APPS:
    case VK_F1: 
    case VK_F2: 
    case VK_F3: 
    case VK_F4: 
    case VK_F5: 
    case VK_F6: 
    case VK_F7: 
    case VK_F8: 
    case VK_F9: 
    case VK_F10: 
    case VK_F11: 
    case VK_F12: 
      
      return TRUE; // If one of the above keys are  pressed then return with this value
				   // to select appropriate message for the message-box at key_pressed() routine. 
  }

  return FALSE;	  // If the key is none of the above (a new system or windows key added to keyboard posteriorly)
				  // then ignore.	  
}



 /* This routine is called when "is_key_pressed()" routine returns TRUE with the keycode of the pressed key
  * Selects the message to be displayed in the message box, determined by the key_pressed and
  * Displays the user name of the person logged in while this program is running.*/
void key_pressed(WPARAM keycode, LPARAM keycode_ext ) // Keycode parameter determines the message to be displayed
{

  char msg_displayed[MAX_PATH + 50]; // Local declaration for text to be  displayed in title bar, 
									 // limited to username + 50 characters.
  char * msg_keypressed;			 // Local declaration for message box text  
  DWORD len_user_name = MAX_PATH;	 // Local declaration for registering username 
									 // MAX_PATH = number of characters in username.

    switch (keycode) // Keycode parameter selects case
    {    
      case VK_MENU:  // If this is the keypressed...
        msg_keypressed = "YOU PRESSED MY ALT KEY";	// Make this the message to be displayed in message box.
        break;										// Same for other cases below.

      case VK_CONTROL:
        msg_keypressed = "YOU PRESSED MY CONTROL KEY";
        break;

      case VK_LWIN:
        msg_keypressed = "YOU PRESSED MY LEFT WINDOWS KEY";
        break;

      case VK_RWIN:
        msg_keypressed = "YOU PRESSED MY RIGHT WINDOWS KEY";
        break;

      case VK_APPS:
        msg_keypressed = "YOU PRESSED MY WINDOWS MENU KEY";
        break;

      case VK_F1: 
        msg_keypressed = "YOU PRESSED MY F1 KEY";
        break;

      case VK_F2: 
        msg_keypressed = "YOU PRESSED MY F2 KEY";
        break;

      case VK_F3: 
        msg_keypressed = "YOU PRESSED MY F3 KEY";
        break;

      case VK_F4: 
        msg_keypressed = "YOU PRESSED MY F4 KEY";
        break;

      case VK_F5: 
        msg_keypressed = "YOU PRESSED MY F5 KEY";
        break;

      case VK_F6: 
        msg_keypressed = "YOU PRESSED MY F6 KEY";
        break;

      case VK_F7: 
        msg_keypressed = "YOU PRESSED MY F7 KEY";
        break;

      case VK_F8: 
        msg_keypressed = "YOU PRESSED MY F8 KEY";
        break;

      case VK_F9: 
        msg_keypressed = "YOU PRESSED MY F9 KEY";
        break;

      case VK_F10: 
        msg_keypressed = "YOU PRESSED MY F10 KEY";
        break;

      case VK_F11: 
        msg_keypressed = "YOU PRESSED MY F11 KEY";
        break;

      case VK_F12: 
        msg_keypressed = "YOU PRESSED MY F12 KEY";
        break;         
  }	
  
  if(!GetUserName(msg_displayed, &len_user_name)) lstrcpy(msg_displayed, "You");
  // If username is not found(no one logged in) then msg_displayed is "You".

  /* alert sounds when message is displayed*/
  Beep(3000, 200); //3000(hertz) = frequency, 200(milliseconds) = duration.
  Beep(2000,100);	
      MessageBox( h_main_window, // Handle to window        
                 msg_keypressed, // Message box text
				 msg_displayed,	 // Title bar text
                 MB_OK);		 // Button	  
  
  /* Sound when OK button is pressed */
  for(int j=1;j<50; j++){ // Increment for raising frequency. 
  Beep((j*50),2);		  // Frequency rises from 50 hertz to 2500 hertz in 100 milliseconds.
  }
}



/* type_launch() is called when a tool is active and mouse is left-clicked.
 * Routines from which it is called are "long CALLBACK WndProc(..) and transition "tool_to_type()".
 * It is freely re-entrant. However, only one "type" box is allowed at a time. 
 * Subsequent calls fail silently.*/
void type_launch(void )
{

  POINT mouse_location;			    // Local declaration for registering cursor position. 
  GetCursorPos(&mouse_location);	// Registers current cursor position.
  
  /* Check for re-entry. */
  if(h_type_window != NULL) return; // If type window handle is active...	
									// return without launching type window.

  /* Creation of Type Window */ 
  h_type_window = CreateWindowEx( 
                                TRANSPARENT,			// Extended window property (doesn't work!) 
								TRANSPARENT_TYPE_CLASS, // Class predefined globally above. 
                                (LPCTSTR) NULL,			// No window title.
                                WS_CHILD |				// This window is child of main_window.
                                ES_RIGHT | ES_MULTILINE | WS_VSCROLL, // Align right, multiline, vertical scrollbar.
                                mouse_location.x - 10,	// x co-ord of topleft corner of window.
                                mouse_location.y - 10,	// y co-ord of topleft corner of window.
                                20 + ( (float) rand() / 100 ), 20 + ( (float) rand() / 100 ), 
														// Randomized window size values of x and y.
                                h_main_window,			// Handle to parent window. 
                                (HMENU) 10001,			// Edit control ID. // applies to context menu. 
                                hinst_main,				// From global save in WinMain(), line 1.
                                NULL);					// Pointer not needed 


  
  ShowWindow(h_type_window, SW_SHOWDEFAULT);// Shows window with above parameters.
  SetFocus(h_type_window);					// Brings the window to foreground.
  Beep(1000,100 );							// Pc speaker sound.
  type_flag = 1;			// Switchs on type flag to say that "type" is active
  

}


/* This routine destroys the type window
 * Called from transition type_to_tool() 
 * Fully re-entrant. Null windows are ignored. 
 * Active windows are killed.*/
void type_kill(void )
{
   
  if(h_type_window == NULL) return;	// Do nothing if handle to type_window does not exist.

  DestroyWindow(h_type_window);		// Kills the type window
  h_type_window = NULL;				// Deactivates  handle to type window
  SetFocus(h_main_window);			// Restores focus to main window 
  type_flag = 0;					// Switches off type flag to say that "type" is not active.
  begin_end_flag = 0;
  
  /* ghost image of the killed window remains because main-window is not asked to repaint itself */

}




/* This routine is called from the long CALLBACK WndProc(...) function when main_window receives a WM_COMMAND message. 
 * It checks to see if the message comes from the type_window, and if it does, messages not ment to be handled by 
 * main_window are filtered out. */
BOOL type_msg_parse(WPARAM wp, LPARAM lp)  // BOOL returns true or false. Parameter contains message.
{  
  if( h_type_window == NULL ) return FALSE;// Not a type message if "type"is inactive.

  switch(HIWORD(wp)){ // Cotains message to be checked. 

  case EN_CHANGE:	  // If the message is about user taking actions to alter text in the type_window...
    return FALSE;	  // do not send it to the main window to be handled.
  }  
  return TRUE;		  // All other messages to be handled by the main_window.

}




/* This routine is called each time a windows character key is pressed.
 * It randomizes the character to  be set into the text window.
 * Called from LABEL_GET_MESSAGE */
void random_char(char * key)

{   
   /* Printable characters begin at ASCII code 32, 
    * and end at 126. */   
   *key = 32 + ( (float) rand() / RAND_MAX * 92 );
   Beep (500, 50);

}



/* This routine is called when a "tool" is active and mouse is left clicked
 * Prepares context to end "tool" and launch "type"
 * Called from function "long CALLBACK Wndroc(...).
 */
void tool_to_type(void ){
  tool_flag = 0;
  begin_end_flag = 0;// For tools that set this flag to "1" when they begin,
					 // to implement appropriate initiations. Reset to "0"
					 // for the next initiation.				
  type_launch();	 // Launches type window.
  tool_count++;		 // Increment "tool" to the next in sequence.    

  if(tool_count > 6) {		// After the last tool in the sequence is launched...
	 tool_count = 0;		// loop the tool sequence.
	 if(hw_value_range<64){ // Until 5 cycles of hw_malfunc_emu()make the desktop
		restore_desktop();	// appear as it did just before the tool was launched. 
							// (Applies to tool_drag_desktop() only).
		}
	 }   
  }





/* Shakes cursor when type is active and cursor moves out of type window.
 * and sends text-string with username to the type window without user input.
 * Called from "long CALLBACK WndProc(...)*/
void shake_cursor(void)
{
/* Display text */
  if(begin_end_flag == 0){			// Flag set to do this only once each time shake_cursor() is called.

  char msg_username[MAX_PATH + 100];// Local definition for text to type window. 100 = limit for number of characters.
  DWORD len_user_name = MAX_PATH;	// Number of characters found in username.

  if(!GetUserName(msg_username, &len_user_name))	// If username doen't exist (no one logged in)...
	  lstrcpy(msg_username, "You");					// Message_user_name = You.
	  
  lstrcat( msg_username, msg_username );// String appended to itself recursively causing apealing harmless error.
  Sleep(30);							// 30 milliseconds wait.
  SendMessage(h_type_window, WM_SETTEXT, 0, (LPARAM) msg_username); //displays text in type window.
  
  begin_end_flag = 1;	// To skip the above until the next time shake_cursor() is called
		}
  
 /* Cursor Shaker */
  POINT mouse_location;			 // Local variable for registerion cursor position.
  GetCursorPos(&mouse_location); // Registers the current position of cursor. 
  while(1){
 /* cursor moves to these four points.
  * tool_cycle incremented by 1 each time the first tool repeats at tool_launch() routine
  * augmenting the cursor-shake effect.
  */
	SetCursorPos( mouse_location.x - (tool_cycle*2), mouse_location.y + (tool_cycle*2));// Moves south west.
	Beep(tool_cycle * 500, tool_cycle*2);// PC Speaker sound increases in frequency @ 500 Hz per tool cycle.
	SetCursorPos( mouse_location.x - (tool_cycle*2), mouse_location.y - (tool_cycle*2));// Moves north west.
	Sleep(tool_cycle*2); //	staccato effect doubles every tool_cycle.
	SetCursorPos( mouse_location.x + (tool_cycle*2), mouse_location.y - (tool_cycle*2));// Moves north east.
	Sleep(tool_cycle*2);	
	SetCursorPos( mouse_location.x + (tool_cycle*2), mouse_location.y + (tool_cycle*2));// Moves south east.
	Sleep(tool_cycle*2);	
	SetCursorPos( mouse_location.x, mouse_location.y);// Reset position to keep the cursor 
													  // from 'slipping' towards one direction. 
	Sleep(tool_cycle*2);
	break;
	}
	
}


 /* This function called from "long CALLBACK WndProc(...)" on two events.
  * 1. After a SYSTEM KEY or WINDOWS KEY is pressed and the user 
  *    has pressed "OK" to the message box generated by "keypressed()" routine.
  * 2. When type flag = 1 and mouse is left clicked  */
void type_to_tool(void )
{
  type_kill();	 // Destroys type window
  type_flag = 0; // Registers type kill
  tool_launch(); // Launches next tool
}


/* Tool launching sequence, cycles and effect-value incrementation.
 * Called from transition routine type_to_tool()and from 
 * "long CALLBACK WndProc(...) when cursor first moves after program has begun*/
void tool_launch(void )
{

  tool_flag = 1;		// Registers that tool is active.
  switch(tool_count){	// Sequences the tools for launching.

  case 0: 
    tool_cursor_trace();
	break;
    
  case 1:
    tool_scratch_vert();
    break;

  case 2:
    tool_flip_vert();
	
    break;

  case 3:
	tool_scratch_horiz();
    break;

  case 4:
    tool_smudge();
	break;

  case 5:
	tool_drag_desktop_invert();
    break;

  case 6:
	  tool_drag_desktop();		 // This tool routine  contains code to loop this sequence.
	  break;

  default:						 // Saftey case for testing. Incase the case number being called doesn't exist
								 // default is called.
    enough_of_acting_the_goat(); 
    break;
  }

  
}



 /* Called from routine: tool_launch().
  * Leaves an images of the cursor on the screen along the path it takes.
  * Begins with another pseudo-cursor at inversely opposite position on the screen
  * Adds two new pseudo-cursors for every tool cycle at other positions on the screen
  * relative to the position of the real/default cursor*/
void tool_cursor_trace(void ){

	/* Tracer for the default cursor.*/
{	
DrawIconEx(
  dc_main_window,                  // Handle to device context
  p1.x - s_cursor_info.xHotspot,   // x-coordinate of upper left corner
  p1.y - s_cursor_info.yHotspot,   // y-coordinate of upper left corner
  h_default_cursor,                // Handle to icon to draw
  NULL,  // Width of the icon
  NULL,  // Height of the icon
  NULL,  // Index of frame in animated cursor
  NULL,  // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL       // Icon-drawing flags
);
	Beep(1000, 1);


	/* Trace pseudo-cursor image at inverse opposite position on screen
	 * Pivot point at the center of the screen */

DrawIconEx(
  dc_main_window,   // Handle to device context
  width_main_window - (p1.x - s_cursor_info.xHotspot),  // x-coordinate of upper left corner
  height_main_window - (p1.y - s_cursor_info.yHotspot), // y-coordinate of upper left corner
  h_default_cursor, // Handle to icon to draw
  NULL,             // Width of the icon
  NULL,             // Height of the icon
  NULL,             // Index of frame in animated cursor
  NULL,             // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL        // Icon-drawing flags
);
}


if (tool_cycle>1){ // Following two pseudo-cursors added at the completion of first tool_cycle. 


 /* Trace pseudo-cursor image at horizontally diametrical opposite position to default cursor
  * Mirror line going horizontally across the middle  of the screen */

DrawIconEx(
  dc_main_window,                // Handle to device context
  p1.x - s_cursor_info.xHotspot, // x-coordinate of upper left corner
  height_main_window - (p1.y - s_cursor_info.yHotspot),  // y-coordinate of upper left corner
  h_default_cursor,              // Handle to icon to draw
  NULL,  // Width of the icon
  NULL,  // Height of the icon
  NULL,  // Index of frame in animated cursor
  NULL,  // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL     // Icon-drawing flags
);


	/* Trace pseudo-cursor image at vertically diametrical opposite position to default cursor
	 * Mirror line going vertically across the middle of the screen */

DrawIconEx(
  dc_main_window,            // Handle to device context
  width_main_window - (p1.x - s_cursor_info.xHotspot), // x-coordinate of upper left corner
  p1.y - s_cursor_info.yHotspot,					   // y-coordinate of upper left corner
  h_default_cursor,          // Handle to icon to draw
  NULL,  // Width of the icon
  NULL,  // Height of the icon
  NULL,  // Index of frame in animated cursor
  NULL,  // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL // Icon-drawing flags
);
}


if (tool_cycle>2){ // Following two pseudo-cursors added at the completion of second tool_cycle. 

	/* Trace pseud-cursor image with x co-ordinate value equivalent to the y co-ordinate value of default cursor 
	 * and with y co-ordinate value equivalent to the x c-ordinate value of default cursor  */
	
DrawIconEx(
  dc_main_window,               // Handle to device context
  p1.y - s_cursor_info.yHotspot,// x-coordinate of upper left corner
  p1.x - s_cursor_info.xHotspot,// y-coordinate of upper left corner
  h_default_cursor,             // Handle to icon to draw
  NULL, // Width of the icon
  NULL, // Height of the icon
  NULL, // Index of frame in animated cursor
  NULL, // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL    // Icon-drawing flags
);


	/* Trace pseud-cursor image with x co-ordinate value inversely opposite to the y co-ordinate value of default cursor 
	 * and with y co-ordinate value inversely opposite to the x co-ordinate value of default cursor  */

DrawIconEx(
  dc_main_window,    // Handle to device context
  width_main_window - (p1.y - s_cursor_info.yHotspot), // x-coordinate of upper left corner
  height_main_window - (p1.x - s_cursor_info.xHotspot),// y-coordinate of upper left corner
  h_default_cursor,  // Handle to icon to draw
  NULL, // Width of the icon
  NULL, // Height of the icon
  NULL, // Index of frame in animated cursor
  NULL, // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL  // Icon-drawing flags
);

	}




if (tool_cycle>3){ // Following two pseudo-cursors added at the completion of third tool_cycle. 

 /* Trace pseud-cursor image with x co-ordinate value equivalent to the y co-ordinate value of default cursor 
  * and with y co-ordinate value inversely opposite to the x co-ordinate value of default cursor  */

DrawIconEx(
  dc_main_window,    // Handle to device context
  p1.y - s_cursor_info.yHotspot,						// x-coordinate of upper left corner
  height_main_window - (p1.x - s_cursor_info.xHotspot), // y-coordinate of upper left corner
  h_default_cursor,  // Handle to icon to draw
  NULL,              // Width of the icon
  NULL,              // Height of the icon
  NULL,				 // Index of frame in animated cursor
  NULL,				 // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL   // Icon-drawing flags
);


 /* Trace pseud-cursor image with x co-ordinate value inversely opposite to the y co-ordinate value of default cursor 
  * and with y co-ordinate value equivalent to the x co-ordinate value of default cursor  */


DrawIconEx(
  dc_main_window,		 // Handle to device context
  width_main_window -  (p1.y - s_cursor_info.yHotspot), // x-coordinate of upper left corner
  p1.x - s_cursor_info.xHotspot,					    // y-coordinate of upper left corner
  h_default_cursor,		// Handle to icon to draw
  NULL,  // Width of the icon
  NULL,  // Height of the icon
  NULL,  // Index of frame in animated cursor
  NULL,  // Handle to background brush
  DI_DEFAULTSIZE | DI_NORMAL      // Icon-drawing flags
);

	}

}




 /* Called from tool_launch() routine.
  * A narrow vertical section of the screen at the x-position of the cursor
  * is copied, flipped vertically and pasted an the same position. */
void tool_scratch_vert(void )
{
  StretchBlt(
	  dc_main_window,      // Handle to destination device context
      p1.x,				   // x-coordinate of upper-left corner of dest. rectangle
      tool_cycle,		   // y-coordinate of upper-left corner of dest. rectangle
      tool_cycle * 4,	   // Width of destination rectangle
      height_main_window,  // Height of destination rectangle
      dc_main_window,      // Handle to source device context
      p1.x,				   // x-coordinate of upper-left corner of source rectangle
      height_main_window,  // y-coordinate of upper-left corner of source rectangle
      tool_cycle * 4,	   // Width of source rectangle
      -height_main_window, // Height of source rectangle
      SRCCOPY			   // Raster operation code
);
Beep(9000, 1);
Beep(10000, 1);
}





 /* Called from routine tool_launch()
  * Copies a rectangle from the screen at the position inversely opposite to the cursor
  * and pastes it at the position of the cursor.*/
void tool_flip_vert(void )
{

  StretchBlt(
      dc_main_window,			 // Handle to destination device context
      p1.x,		// x-coordinate of upper-left corner of dest. rectangle
      p1.y ,	// y-coordinate of upper-left corner of dest. rectangle
      120,		// Width of destination rectangle
      90,		// Height of destination rectangle
      dc_main_window,			// Handle to source device context
      width_main_window - p1.x, // x-coordinate of upper-left corner of source rectangle
      height_main_window - p1.y,// y-coordinate of upper-left corner of source rectangle
      -120 / tool_cycle,		// Width of source rectangle
      -90 / tool_cycle,			// Height of source rectangle
      SRCCOPY   // Raster operation code
);

Beep(600, 1);
Beep(150, 1);



}



/* Called from routine tool_launch()
 * A narrow horizontal section of the screen at the y position of the cursor 
 * is displaced  horizontally by a few pixels.*/
void tool_scratch_horiz(void )
{

  StretchBlt(

      dc_main_window,      // Handle to destination device context
      tool_cycle,		   // x-coordinate of upper-left corner of dest. rectangle
      p1.y,				   // y-coordinate of upper-left corner of dest. rectangle
      width_main_window,   // Width of destination rectangle
      tool_cycle,		   // Height of destination rectangle
      dc_main_window,      // Handle to source device context
      0,	 // x-coordinate of upper-left corner of source rectangle
      p1.y,  // y-coordinate of upper-left corner of source rectangle
      width_main_window,    // Width of source rectangle
      tool_cycle,		    // Height of source rectangle
      SRCCOPY				// Raster operation code
);
Beep(8000, 1);
Beep(11000, 1);

}



 /* Called from routine tool_launch()
  * A rectangular section of the screen copied from one side of the cursor
  * flipped horizontally and vertically, and pasted on the other side of the cursor.*/
void tool_smudge(void )
{

  StretchBlt(
      dc_main_window,     // Handle to destination device context
      p1.x,		// x-coordinate of upper-left corner of dest. rectangle
      p1.y,		// y-coordinate of upper-left corner of dest. rectangle
      120,		// Width of destination rectangle
      90,		// Height of destination rectangle
      dc_main_window,	  // Handle to source device context
      p1.x,		// x-coordinate of upper-left corner of source rectangle
      p1.y,		// y-coordinate of upper-left corner of source rectangle
      -60 * tool_cycle,   // Width of source rectangle
      -45 * tool_cycle,   // Height of source rectangle
      SRCCOPY   // Raster operation code
);
Beep(900, 1);
Beep(300, 1);

}


/* Called from routine tool_launch()
 * A color negative image of the screen displaced from the center 
 * to the inverse opposite position on the screen to that of the cursor. 
 * Visible only when the cursor is moving. */
void tool_drag_desktop_invert(void)
{

    if(begin_end_flag == 0){ // When this routine begins...
    release_desktop();		 // Delete the desktop image saved by another routine...
    save_desktop();			 // Save it afresh
    begin_end_flag = 1;		 // Register that this has been done

    /* Small hack for centering mouse cursor. */
    SetCursorPos(width_main_window/2, height_main_window/2);
	
  }
  
  BitBlt(
    dc_main_window,     // Handle to destination device context
    width_main_window/2 - p1.x,  // x-coordinate of destination rectangle's upper-left corner
    height_main_window/2 - p1.y, // y-coordinate of destination rectangle's upper-left corner
    width_main_window,  // Width of destination rectangle
    height_main_window, // Height of destination rectangle
    dc_saved,   // Handle to source device context
    0,          // x-coordinate of source rectangle's upper-left corner
    0,          // y-coordinate of source rectangle's upper-left corner
    SRCINVERT   // Raster operation code
    );
Beep(2000, 50);
restore_desktop(); // Makes this effect invisible when the cursor stops moving. 
}



 /* Called from routine tool_launch()
  * Screen displaced to the position inversly opposite to that of cursor position.
  * Unlike tool_drag_desktop_invert(), this effect remains visible when cursor stops moving */
void tool_drag_desktop(void)
{
	
    if(begin_end_flag == 0){ // When this routine begins...
	    release_desktop();	 // Clear the desktop image saved by another routine
		save_desktop();		 // Save the desktop image afresh
		begin_end_flag = 1;	 // Register that this has been done.

    /* Centers cursor. */
	SetCursorPos(width_main_window/2, height_main_window/2);
	
	/* Increment tool effects at each tool cycle and end program at 6 tool_cycles */
	tool_cycle = tool_cycle + 1;
	if(tool_cycle == 6){			   // When 6 tool_cycles have completed call...
		  enough_of_acting_the_goat(); // the end program routine.
	  }
  }
  
  BitBlt(
    dc_main_window,			    // Handle to destination device context
    width_main_window/2 - p1.x, // x-coordinate of destination rectangle's upper-left corner
    height_main_window/2 - p1.y,// y-coordinate of destination rectangle's upper-left corner
    width_main_window,  // Width of destination rectangle
    height_main_window, // Height of destination rectangle
    dc_saved,           // Handle to source device context
    0,       // x-coordinate of source rectangle's upper-left corner
    0,       // y-coordinate of source rectangle's upper-left corner
    SRCCOPY  // Raster operation code
    );
Beep(6000, 1);

}


 /* Called from all hw_malfunc_emu_xxx() sub-routines and
  * tool_drag_desktop() and tool_drag_desktop_invert().
  * Saves an image of the desktop @ dc_saved */ 
void save_desktop(void)
{
	if(!dc_saved){	// If device context "dc_saved" has not been saved
  dc_saved = CreateCompatibleDC(dc_main_window);				// Create dc_saved from dc_main_window
  h_desktop_bitmap = CreateCompatibleBitmap(dc_main_window,		// With bitmap from dc_main_window
                                            width_main_window,	// of the same dimensions
                                            height_main_window);//...
  }
  SelectObject(dc_saved, h_desktop_bitmap); // Replaces old image with new image

  BitBlt(
		  dc_saved, // Handle to destination device context
          0,		// x-coordinate of destination rectangle's upper-left corner
          0,		// y-coordinate of destination rectangle's upper-left corner
          width_main_window, // Width of destination rectangle
          height_main_window,// Height of destination rectangle
          dc_main_window,	 // Handle to source device context
          0,	    // x-coordinate of source rectangle's upper-left corner
          0,		// y-coordinate of source rectangle's upper-left corner
          SRCCOPY	// Raster operation code
          );
          
}


 /* Called from all routines that call te save_desktop() function.
  * Clears the device context and desktop image saved by the previous 
  * routine that called it before calling the save_desktop() function 
  * to update the desktop image*/
void release_desktop(void){
	if(dc_saved){					// If this device context is saved... 
    DeleteObject(h_desktop_bitmap); // delete the saved desktop image...
    DeleteDC(dc_saved);				// and the device context
  }
  h_desktop_bitmap = NULL;			// Register both as absent
  dc_saved = NULL;
}


/* Called from all "hw_malfunct_emu_xxx" and  the two desktop dragging tools.
 * Restores the desktop image in the main_window to what it was before these
 * functions tampered them.*/
void restore_desktop(void){
BitBlt(
      dc_main_window, // Handle to destination device context
      0,      // x-coordinate of destination rectangle's upper-left corner
      0,      // y-coordinate of destination rectangle's upper-left corner
      width_main_window,  // Width of destination rectangle
      height_main_window, // Height of destination rectangle
      dc_saved,           // Handle to source device context
      0,              // x-coordinate of source rectangle's upper-left corner
      0,              // y-coordinate of source rectangle's upper-left corner
    SRCCOPY			  // Raster operation code 
    );
}




 /* Calls malfunction emulations in a sequence, counts cycles and increments effect-value.
  * Called from main routine "long CALLBACK WndProc(...) when mouse is right clicked*/
void hw_malfunc_emu(void )
{
  hw_malfunc_count++;		// Increments the case value of hw_malfunc_emu_xxx to be called.
  switch(hw_malfunc_count){ // Selects the next hw_malfunc_emu_xxx in sequence.


  case 1: 

    hw_malfunc_emu_quiver();
	break;

  case 2: 
    hw_malfunc_emu_jitterpaint();
	break;
  
  case 3: 
    hw_malfunc_emu_quiver_invert();
	break;	
  
  case 4: 
    hw_malfunc_emu_vhold();
	break;
  
  case 5: 
    hw_malfunc_emu_flash_invert();
	break;
  
  case 6: 
    hw_malfunc_emu_hhold();
	break;
  
  case 7: 
    hw_malfunc_emu_slicenshuffle();
    break;

  case 8: 
    hw_malfunc_emu_jitter();
    break;

  case 9: 
    hw_malfunc_emu_vhold_noise();		 // After the last tool in the sequence...
	hw_value_range = hw_value_range * 2; // Double the values of the malfunction effect
	hw_malfunc_count = 0;				 // Loop the sequence
	if (hw_value_range == 64){			 // If the sequence has looped 5 times
		enough_of_acting_the_goat();	 // call the end program routine.
	}
    break;
  }

}


/* HARDWARE MALFUNCTION EMULATIONS*/

	/* CHERRY: All hw_malfunc_emu_xxx() are synchronous calls, ie; they don't quit until 
	  the effect runs for the number of milliseconds specified locally in relation to 
	  HW_TIMEOUT. I feel that implementing this in a multithreaded/asynchronous fashion 
	  makes the program complicated. The whole point of these effects, in any case, is 
	  that they alarm the user for a short time. */



 /* Screen sliced into many (160) vertical sections that 
  * oscillate vertically at different displacement rates.
  * Called from hw_malfunc_emu()*/
void hw_malfunc_emu_quiver(void )
{
  int i; // local integer declaration
  
  DWORD timer_ticks; // local declaration for registering TickCount
  release_desktop(); // Clears desktop image saved by another routine
  save_desktop();	 // Saves the desktop image afresh


	/* We declare 160 parallel strips of the screen. Each strip
     * is to jitter up and down for a random height. */

  HDC dc_jitter[160];		  // Local declaration of handle to device context, 160pcs.
  HBITMAP jitter_bitmap[160]; // Local declaration of handle to bitmap, 160pcs.

   for (i=0; i<160; i++){	  // Integer "i" incremented by one at each loop of this sub-block till it reaches 160.
							  // After 160 loops program continues to the next block.
    dc_jitter[i] = CreateCompatibleDC(dc_main_window);		  // Creates a DC with the current value of "i"... 
															  // from the DC of main_window.
    jitter_bitmap[i] = CreateCompatibleBitmap(dc_main_window, // Creates a bitmap with the current value of "i"...
																		// from main_window.
                                              width_main_window / 160,  // With this width
                                              height_main_window);		// and this height.
    /* Save the (i) number of strips into memory. */
     SelectObject(dc_jitter[i], jitter_bitmap[i] ); // Replaces these objects
      
    BitBlt(dc_jitter[i],	// Handle to destination device context, current value of "i".
              0,			// x-coordinate of destination rectangle's upper-left corner
              0,			// y-coordinate of destination rectangle's upper-left corner
              width_main_window / 160,	 // Width of destination rectangle
              height_main_window,		 // Height of destination rectangle
              dc_main_window,			 // Handle to source device context
              width_main_window /160 * i,// x-coordinate of source rectangle's upper-left corner...
										 // determined by the current value of "i".
              0,				// y-coordinate of source rectangle's upper-left corner
              SRCCOPY			// Raster operation code 
              );
  
  }
  /* When "i" > 160 program goes to the following sub-block*/
  timer_ticks = GetTickCount(); //register current TickCount.
  
  while(1){ // Loops this block till timeout occurs.
    
    /* Display the (i) strips side by side. */
	  for (i=0; i<160; i++){ // Integer "i" incremented by one at each loop of this sub-block till it reaches 160.
							 // while() makes this sub-block loops further till HW_TIMEOUT occurs.
    BitBlt(dc_main_window,	 // Handle to destination device context.
              (width_main_window /160 * i) + i, // x-coordinate of destination rectangle's upper-left corner,
												// current value of "i".
              hw_value_range * ( (float) rand() / RAND_MAX ), // y-coordinate of destination rectangle's upper-left corner
															  // rand assigns each strip a different value, 
															  // hw_value_range amplifies the rand value at each 
															  // hw_malfunc_emu() cycle.
              width_main_window / 160,  // Width of destination rectangle
              height_main_window,		// Height of destination rectangle
              dc_jitter[i],				// Handle to source device context
              0,						// x-coordinate of source rectangle's upper-left corner
              0,						// y-coordinate of source rectangle's upper-left corner
              SRCCOPY					// Raster operation code 
              );
    }

    /* We ignore all user input, during the hardware malfunction emulation.
    If we don't flush the message queue, clicks will accumulate and
    can cause the program to wait a long while before it exits. */
    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);  
    Beep(40, 1);
    if( (GetTickCount() - timer_ticks) / 500 > HW_TIMEOUT){	// If current tickcount is 1000 more than time_ticks registered
															// at beginning of this while() block, end this effect.
		if((hw_value_range<32) && (tool_cycle<4)){			// Don't restore_desktop if tool_launch() has gone through 4
		restore_desktop();									// cycles or hw_malfunc_emu() has gone through 5 cycles.
		}
	break;
	}
  }

/* Clean up before ending routine.*/
  for (i=0; i<160; i++ ){
    DeleteObject(jitter_bitmap[i]);
    DeleteDC(dc_jitter[i]);
  }
}



/* Screen shakes vertically and changes color at flashes.
 * Called from hw_malfunc_emu() routine */
void hw_malfunc_emu_jitterpaint(void)
{

  DWORD timer_ticks; // Local declaration for registering TickCount
  release_desktop(); // Delete desktop image saved by another routine
  save_desktop();	 // Save desktop image afresh
  timer_ticks = GetTickCount(); // Register current TickCount

  int i = 1;	// Local integer declaration for displacing screen
 while(1){		// Loops this block till timeout occurs.	 
	 

	BitBlt(
      dc_main_window,		// Handle to destination device context
     0,						// x-coordinate of destination rectangle's upper-left corner
     i * -(hw_value_range), // y-coordinate of destination rectangle's upper-left corner
							// hw_value_range doubles after every hw_malfunc_emu() cycle
     width_main_window,  // Width of destination rectangle
     height_main_window, // Height of destination rectangle
     dc_saved,           // Handle to source device context
     0,             // x-coordinate of source rectangle's upper-left corner
     0,             // y-coordinate of source rectangle's upper-left corner
     SRCPAINT       // Raster operation code. Create a faded image of the source
    );
	Sleep(100);		// Wait 100 milliseconds to make this effect visible 
					// for monitors with low refresh rates.

	BitBlt(
      dc_main_window,    // Handle to destination device context
     0,				     // x-coordinate of destination rectangle's upper-left corner
     i * hw_value_range, // y-coordinate of destination rectangle's upper-left corner
						 // hw_value_range doubles after every hw_malfunc_emu() cycle
     width_main_window,  // Width of destination rectangle
     height_main_window, // Height of destination rectangle
     dc_saved,   // Handle to source device context
     0,          // x-coordinate of source rectangle's upper-left corner
     0,          // y-coordinate of source rectangle's upper-left corner
     SRCCOPY     // Raster operation code
    );
	Sleep(10);	 // Wait 100 milliseconds to make this effect visible 
				 // for monitors with low refresh rates 

	i = i+1;	  // Increment "i" by 1 until...
	if (i>4) i=1; // "i" = 4, then make "i" 1 again
	
  /* For comments to the following, look up routine: hw_malfunc_emu_quiver()*/  
    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	Beep(6000, 2);

    if( (GetTickCount() - timer_ticks) / 500 > HW_TIMEOUT) {
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
		break;
	}
  }
}



/* Identical to routine: hw_malfunc_emu_quiver() except that here the screen colors
 * alternate between negative and positive while quivering
 * Called from hw_malfunc_emu()
 * For comments to this routine look up hw_malfunc_emu_quiver() */
void hw_malfunc_emu_quiver_invert(void )
{
  int i;
  DWORD timer_ticks;
  release_desktop();
  save_desktop();
  
 
  HDC dc_jitter[160];
  HBITMAP jitter_bitmap[160];
  
  for (i=0; i<160; i++){
    dc_jitter[i] = CreateCompatibleDC(dc_main_window);
    jitter_bitmap[i] = CreateCompatibleBitmap(dc_main_window,
                                              width_main_window / 160,
                                              height_main_window);
        
    SelectObject(dc_jitter[i], jitter_bitmap[i] );
      
    BitBlt(dc_jitter[i],
              0,
              0,
              width_main_window / 160,
              height_main_window,
              dc_main_window,
              width_main_window /160 * i,
              0,
              SRCCOPY
              );
  
  }

  timer_ticks = GetTickCount();
  
  while(1){
    
    for (i=0; i<160; i++){

    BitBlt(dc_main_window,
              (width_main_window /160 * i) + i,
              hw_value_range * ( (float) rand() / RAND_MAX ),
              width_main_window / 160,
              height_main_window,
              dc_jitter[i],
              0,
              0,
              SRCINVERT // Raster operation code. This creates the negative image
              );
    
    }

    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
    Beep(90, 1);
	Beep(180, 1);
	Beep(360, 1);
	Beep(6000, 1);

    if( (GetTickCount() - timer_ticks) / 500 > HW_TIMEOUT){
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
	break;
	}
  }

  for (i=0; i<160; i++ ){
    DeleteObject(jitter_bitmap[i]);
    DeleteDC(dc_jitter[i]);
  }
}


  
/* Screen rolls vertically. speed and direction relative to the y position of cursor.
 * Called from routine hw_malfunc_emu().*/
void hw_malfunc_emu_vhold(void )

	
  
{

  long yvhold_top=0,	// y position of the top left corner of main instance  of the desktop image to be displaced.
	   yvhold_bottom=0; // y position of the top left corner of the "filler" instance of desktop image.
						// Fills the area of screen left empty by the main instance of the displaced desktop image.
  POINT mouse_location;	// Local definition for registering cursor position
  DWORD timer_ticks;	// Local definition for registering TickCount

  /*  Algo :
     - Save Desktop Snapshot.
     - Get timer tick.   
     - hw_value_range loop:
     - Get current mouse cursor y-axis = mouse_location.y
     - Set speed proportional to mouse_location.y
     - Display Desktop Snapshot @ x, y+=abs(mouse_location.y)
     - break if timer reached HW_TIMEOUT.
  */
  release_desktop();			// Deletes the saved desktop image
  save_desktop();				// Saves the desktop image afresh
  timer_ticks = GetTickCount(); // Registers tickcount before effect takes place
  SetCursorPos( width_main_window / 2, height_main_window / 2 + 15 ); // moves cursor slightly above the center-point 
																	  // on the y-axis to set the screen rolling slowly.

  while(1){
 
    
     GetCursorPos(&mouse_location); // Retreive cursor position to determine speed and direction for the screen to roll.

    /* increment yvhold within screen limits. */
    yvhold_top += ( height_main_window/2 - mouse_location.y ) * 0.3;
	// yvhold_top value starts at 0.
	// If the cursor is above the mid-point on the y axis yvhold_top begins to increase.
	// If the cursor is below the mid-point on the y axis yvhold_top begins to decrease.
	// The rate at which yvhold to increases or decreases is proportional to the distance between
	// the cursor and the midpoint on the y axis.
    
	yvhold_top = ( yvhold_top > height_main_window) ? 0 : yvhold_top;
	// If yvhold_top is greater than the height_main_window, then make yvhold_top 0. Else let it remain what it is.
	// When the top edge of the displaced main desktop image crosses the bottom edge of the screen
	// it pops back to default position.
    yvhold_top = ( ( yvhold_top + height_main_window ) < 0 )  ? 0 : yvhold_top;
    // If yvhold_top + height_main_window is lesser than 0, then make yvhold_top 0. Else let it remain what it is
	// When the bottom edge of the displaced main desktop image crosses the top edge of the screen
	// it pops back to default position.

    yvhold_bottom = ( yvhold_top < 0 ) ? yvhold_top + height_main_window : yvhold_bottom;
	// If yvhold_top is lesser than 0, then yvhold_bottom =(yvhold_top + height_main_window).Else let it remain what it is.
    // When the main desktop image is displaced north-wards,
	// then the filler desktop image occupies the lower part of the screen left vacant.
	yvhold_bottom = ( yvhold_top >= 0 ) ? yvhold_top - height_main_window : yvhold_bottom;
    // If yvhold_top is greater than 0, then yvhold_bottom = (yvhold_top - height_main_window).Else let it remain what it is.
    // When the main desktop image is displaced south-wards 
	// then the filler desktop image occupies the upper part of the screen left vacant.
	
    /* Display the main desktop image */    
    BitBlt(
      dc_main_window,     // Handle to destination device context
      0,				  // x-coordinate of destination rectangle's upper-left corner
      yvhold_top,		  // y-coordinate of destination rectangle's upper-left corner
      width_main_window,  // Width of destination rectangle
      height_main_window, // Height of destination rectangle
      dc_saved, // Handle to source device context
      0,        // x-coordinate of source rectangle's upper-left corner
      0,        // y-coordinate of source rectangle's upper-left corner
    SRCCOPY     // Raster operation code
    );

  /* Display the filler desktop image */    
    BitBlt(
      dc_main_window,     // Handle to destination device context
      0,				  // x-coordinate of destination rectangle's upper-left corner
      yvhold_bottom,      // y-coordinate of destination rectangle's upper-left corner
      width_main_window,  // Width of destination rectangle
      height_main_window, // Height of destination rectangle
      dc_saved, // Handle to source device context
      0,        // x-coordinate of source rectangle's upper-left corner
      0,        // y-coordinate of source rectangle's upper-left corner
    SRCCOPY     // Raster operation code 
    );

    
    /* We ignore all user input, during the hardware malfunction emulation.
    If we don't flush the message queue, clicks will accumulate and
    can cause the program to wait a long while before it exits. */    
    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);

	/* PC Speaker Sound relative to the change in screen displacement values */
	Beep(yvhold_bottom + 37, 1);
    Beep(yvhold_top + 37, 1);

	/* Time Out: for comments look up routine hw_malfunc_emu_quiver()*/
	if( (GetTickCount() - timer_ticks) / 1000 > HW_TIMEOUT){
		if((hw_value_range<32) && (tool_cycle<4)) {
		restore_desktop();
		}
		break;
	}
  }
}





/* Screen color alternates between negetive and positive.
 * Also shifts slightly with random values in x and y axes creating a blurred effect. 
 * Called from hw_malfunc_emu() */
void hw_malfunc_emu_flash_invert(void )
{
  DWORD timer_ticks;			// Local declaration for registering TickCount
  release_desktop();			// Delete desktop image saved by another routine
  save_desktop();				// Save desktop image afresh
  timer_ticks = GetTickCount(); // Register current TickCount
  
 while(1){
  BitBlt(
      dc_main_window,     // Handle to destination device context
      hw_value_range  * ( (float) rand() / RAND_MAX ), // x-coordinate of destination rectangle's upper-left corner
      hw_value_range * ( (float) rand() / RAND_MAX ),  // y-coordinate of destination rectangle's upper-left corner
      width_main_window,  // Width of destination rectangle
      height_main_window, // Height of destination rectangle
      dc_saved,           // Handle to source device context
      0,              // x-coordinate of source rectangle's upper-left corner
      0,              // y-coordinate of source rectangle's upper-left corner
      SRCINVERT       // raster operation code, creates a color negetive image.
    );

  /* For comments to the following, look up routine: hw_malfunc_emu_quiver()*/ 
    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	Beep(6000, 2);
    if( (GetTickCount() - timer_ticks) / 500 > HW_TIMEOUT) {
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
		break;
	}
  }
}



/* Identical to hw_malfunc_emu_vhold() except that this works horizontally.
 * Look up hw_malfunc_emu_vhold() for comments.
 * Top and bottom in vhold are replaced here with left and right, respectively.
 * Called from hw_malfunc_emu(0. */
void hw_malfunc_emu_hhold(void )
{

  long xhhold_left=0, xhhold_right=0;
  POINT mouse_location;
  DWORD timer_ticks; 
  release_desktop();
  save_desktop();
  timer_ticks = GetTickCount();
  SetCursorPos( width_main_window / 2 + 15, height_main_window / 2 );

  while(1){    
     GetCursorPos(&mouse_location);

    xhhold_left += ( width_main_window/2 - mouse_location.x ) * 0.3;
    xhhold_left = ( xhhold_left > width_main_window) ? 0 : xhhold_left;
    xhhold_left = ( ( xhhold_left + width_main_window ) < 0 )  ? 0 : xhhold_left;
 
    xhhold_right = ( xhhold_left < 0 ) ? xhhold_left + width_main_window : xhhold_right;
    xhhold_right = ( xhhold_left >= 0 ) ? xhhold_left - width_main_window : xhhold_right;
        
    BitBlt( dc_main_window, xhhold_left, 0, width_main_window, height_main_window, dc_saved, 0, 0, SRCCOPY );
    BitBlt(dc_main_window, xhhold_right, 0, width_main_window, height_main_window, dc_saved, 0, 0, SRCCOPY );

    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	Beep(xhhold_left*10, 1);
    Beep(xhhold_right*10, 1);
    if( (GetTickCount() - timer_ticks) / 1000 > HW_TIMEOUT){
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
		break;
	}
  }
}




/* Screen sliced into assorted rectangular sections and shuffled around a few times. 
 * Called from hw_malfunc_emu()*/
void hw_malfunc_emu_slicenshuffle(void )
{
  DWORD timer_ticks; // Local declaration for registering TickCount
  release_desktop(); // Delete desktop image saved by another routine
  save_desktop();	 // Save desktop image afresh
  timer_ticks = GetTickCount(); // Register current TickCount

  while(1){  // Loops this bock until timeout.
    BitBlt(
        dc_main_window,     // Handle to destination device context
        width_main_window * ((float) rand() / RAND_MAX) - width_main_window/2, 
		// x-coordinate of destination rectangle's upper-left corner
        height_main_window * ((float) rand() / RAND_MAX) - height_main_window/2, 
		// y-coordinate of destination rectangle's upper-left corner
        width_main_window,  // Width of destination rectangle
        height_main_window, // Height of destination rectangle
        dc_saved,           // Handle to source device context
        0,              // x-coordinate of source rectangle's upper-left corner
        0,              // y-coordinate of source rectangle's upper-left corner
        SRCCOPY         // Raster operation code
    );
  /* PC Speaker Sounds */
	Beep(((float) rand() / RAND_MAX) * 100, 10);
	Beep(((float) rand() / RAND_MAX) * 1000, 10);
	
  /* For comments to the following, look up routine: hw_malfunc_emu_quiver()*/  
   PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	Beep(700, 2);
  if( (GetTickCount() - timer_ticks) / 200 > HW_TIMEOUT){
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
		break;
	}
  }
}


 /* Screen vibrates diagonally
  * Called from hw_malfunc_emu()*/
void hw_malfunc_emu_jitter(void )
{

  DWORD timer_ticks; // Local declaration for registering TickCount
  release_desktop(); // Delete desktop image saved by another routine
  save_desktop();	 // Save desktop image afresh
  timer_ticks = GetTickCount(); // Register current TickCount


  int i = 0; // Local integer declaration
 while(1){	// loops following till time-out.
	 
	BitBlt(
      dc_main_window,     // handle to destination device context
     i * hw_value_range,          // x-coordinate of destination rectangle's upper-left 
                 // corner
     -i * hw_value_range,       // y-coordinate of destination rectangle's upper-left 
                    // corner
     width_main_window,  // width of destination rectangle
     height_main_window, // height of destination rectangle
     dc_saved,           // handle to source device context
     0,              // x-coordinate of source rectangle's upper-left 
                      // corner
     0,              // y-coordinate of source rectangle's upper-left 
                      // corner
     SRCCOPY           // raster operation code
    );

	i = i+1; // "i" incremented by 1 until...
	if (i>4) i=1;// "i" is 4 and then "i" is 1 again.
	
  /* We ignore all user input, during the hardware malfunction emulation.
    If we don't flush the message queue, clicks will accumulate and
    can cause the program to wait a long while before it exits. */

   /* For comments to the following, look up routine: hw_malfunc_emu_quiver()*/  
    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	Beep(700, 2);
    if( (GetTickCount() - timer_ticks) / 520 > HW_TIMEOUT) {
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
		break;
	}
  }
}


/* Identical to hw_malfunc_emu_vhold_noise() except that the filler desktop image generates visual noise.
 * For comments to this routine look up hw_malfunc_emu_vhold_noise().
 * Called from hw_malfunc_emu(). */
void hw_malfunc_emu_vhold_noise(void )
{
  long yvhold_top=0, yvhold_bottom=0;
  POINT mouse_location;
  DWORD timer_ticks;
  release_desktop();
  save_desktop();
  timer_ticks = GetTickCount();
  SetCursorPos( width_main_window / 2, height_main_window / 2 + 15 );

  while(1){
     GetCursorPos(&mouse_location);
    yvhold_top += ( height_main_window/2 - mouse_location.y ) * 0.3;
    yvhold_top = ( yvhold_top > height_main_window) ? 0 : yvhold_top;
    yvhold_top = ( ( yvhold_top + height_main_window ) < 0 )  ? 0 : yvhold_top;
 
    yvhold_bottom = ( yvhold_top < 0 ) ? yvhold_top + height_main_window : yvhold_bottom;
    yvhold_bottom = ( yvhold_top >= 0 ) ? yvhold_top - height_main_window : yvhold_bottom;
      
    BitBlt( dc_main_window, 0, yvhold_top, width_main_window, height_main_window, dc_saved, 0, 0, SRCCOPY);
 
    BitBlt(
      dc_main_window, 0, yvhold_bottom, width_main_window, height_main_window, dc_saved, 0, 0,
    SRCINVERT //This is the only parameter that makes this routine different from hw_malfunc_emu_vhold().
    );
    
    PeekMessage(&msg, NULL, 0, 0, PM_REMOVE);
	Beep(yvhold_bottom + 37, 1);
    Beep(yvhold_top + 37, 1);

	if( (GetTickCount() - timer_ticks) / 1000 > HW_TIMEOUT){
		if((hw_value_range<32) && (tool_cycle<4)){
		restore_desktop();
		}
		break;
	}
  }
}



  
/* End Program routine.
 * Creates a zoom-out effect of the screen before displaying message box.
 * Deletes this program after it has quit.
 * Called from: "long CALLBACK wndProc(..)" on the event of mouse middle-click,
 *				or upon receiving WM_DESTROY or WM_CLOSE messages;
 *		  from: tool_launch(), default case, if a case number is not found;
 *        from: tool_drag_desktop() when tool cycle == 6;
 *	  and from: hw_malfunc_emu() when hw_value_range == 64 (6 cycles).
 */
  void enough_of_acting_the_goat(void )
{
 /* Initial dimensions of screen source copied to be pasted */
  int copy_paste_width = width_main_window;
  int copy_paste_height = height_main_window;
  // after the paste operation the next dimension values of source to be copied
  // will reduce to those of the shrunk-down destination into which the former was pasted.   

 /* Initial co-ordinates of top left corner of screen source copied to be pasted */
  int copy_paste_x =0;
  int copy_paste_y =0;
  // These will increase in value to make the co-ordinates of the next source to be copied 
  // equal to that of the shrunk-down and centered destination of the former.

  for(int i=30;i>1; i--){ // operation to be carried out 30 times.	
  Beep(32+i*5,(30-i)*8); // frequency and duration of PC speaker sounds reduce with "i" for each operation.
  
 
  StretchBlt(
      dc_main_window,      // handle to destination device context
      (width_main_window - (copy_paste_width - (copy_paste_width / 10))) / 2, 
	  // x-coordinate of upper-left corner of dest. rectangle
      (height_main_window - (copy_paste_height - (copy_paste_height / 10))) / 2, 
	  // y-coordinate of upper-left corner of dest. rectangle
      copy_paste_width - (copy_paste_width / 10),   // width of destination rectangle
      copy_paste_height - (copy_paste_height / 10),  // height of destination rectangle
      dc_main_window,       // handle to source device context
      copy_paste_x,  // x-coordinate of upper-left corner of source rectangle
      copy_paste_y,  // y-coordinate of upper-left corner of source rectangle
      copy_paste_width,    // width of source rectangle
      copy_paste_height,   // height of source rectangle
      SRCCOPY       // raster operation code
);
	copy_paste_width = copy_paste_width - (copy_paste_width / 10);
	copy_paste_height = copy_paste_height - (copy_paste_height / 10);
	copy_paste_x = (width_main_window - copy_paste_width) / 2;
	copy_paste_y = (height_main_window - copy_paste_height) / 2;
	 }
	Beep(37,1000);

/* The maximum size of the "This program is tired of message" is set to 100. */

  //char msg_displayed[ MAX_PATH + 100 ];
  char msg_username[ MAX_PATH ];  
  DWORD len_user_name = MAX_PATH;	

  if(!GetUserName(msg_username, &len_user_name))	//if username is not found...
      lstrcpy(msg_username, "You");		//msg_username = "You"
   //lstrcat(msg_username, "     bye,");
  //wsprintf(msg_displayed, "I am tired of %s", msg_username);

   MessageBox( h_main_window,	//handle to window
			   "        BYE",	//message
               msg_username,	//title text
               MB_OK );			//OK button
     
   release_desktop();	//clears garbage
   SelfDelete();	// Deletes this Program from the users disk.
   PostQuitMessage(0);

}


/* Deletes this program file from the user's disk after closing.
 * Called from enough_of_acting_the_goat().
 * This code written by Tony Varnas. Thank you Tony!
 */
BOOL SelfDelete()
{
  TCHAR szFile[MAX_PATH], szCmd[MAX_PATH];

  if((GetModuleFileName(0,szFile,MAX_PATH)!=0) &&
     (GetShortPathName(szFile,szFile,MAX_PATH)!=0))
  {
    lstrcpy(szCmd,"/c del ");	
    lstrcat(szCmd,szFile);
    lstrcat(szCmd," >> NUL");

    if((GetEnvironmentVariable("ComSpec",szFile,MAX_PATH)!=0) &&
       ((INT)ShellExecute(0,0,szFile,szCmd,0,SW_HIDE)>32))
       return TRUE;
  }
  return FALSE;
}

  /* Over and Out !!! */